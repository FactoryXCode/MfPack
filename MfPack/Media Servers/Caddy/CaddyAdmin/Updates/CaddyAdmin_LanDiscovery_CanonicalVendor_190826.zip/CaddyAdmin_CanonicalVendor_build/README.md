CaddyAdmin LAN discovery - canonical MAC vendor database revision

Changes:
- mac-vendors.txt is the single canonical UTF-8 vendor database filename.
- Searches beside the executable and up to four parent folders.
- mac-vendors.csv remains an optional fallback.
- PREFIX=Vendor parsing and 24/28/36-bit longest-prefix lookup are preserved.
- The old seed mac-vendors.txt is intentionally NOT included in this archive,
  so extracting the project cannot overwrite your full vendor database.

Place your complete mac-vendors.txt beside CaddyAdmin.exe or in one of the
searched parent/project folders.
