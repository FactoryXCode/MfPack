unit dlgLanDiscovery;

interface

uses
  WinApi.Windows,
  WinApi.Messages,
  System.SysUtils,
  System.Classes,
  Vcl.Controls,
  Vcl.StdCtrls,
  Vcl.ExtCtrls,
  Vcl.ComCtrls,
  Vcl.Forms;

type
  TLanDiscoveryDialog = class;

  TLanDiscoveryThread = class(TThread)
  private
    FResults: TStringList;
    FAliases: TStringList;
    FProgress: Integer;
    FTotal: Integer;
    FFinishedFlag: Integer;
    FErrorText: string;
    procedure AddAddress(const AAddress: string);
  protected
    procedure Execute(); override;
  public
    constructor Create();
    destructor Destroy(); override;
    function IsFinished(): Boolean;
    function Progress(): Integer;
    function Total(): Integer;
    property Results: TStringList read FResults;
    property Aliases: TStringList read FAliases;
    property ErrorText: string read FErrorText;
  end;

  TLanDiscoveryDialog = class(TForm)
    lblStatus: TLabel;
    pbDiscovery: TProgressBar;
    lvDevices: TListView;
    btnRefresh: TButton;
    btnUseIP: TButton;
    btnCancel: TButton;
    tmrDiscovery: TTimer;
    procedure tmrDiscoveryTimer(Sender: TObject);
    procedure btnRefreshClick(Sender: TObject);
    procedure btnUseIPClick(Sender: TObject);
    procedure lvDevicesDblClick(Sender: TObject);
    procedure lvDevicesSelectItem(Sender: TObject; Item: TListItem;
                                  Selected: Boolean);
  private
    FWorker: TLanDiscoveryThread;
    FAddress: string;
    procedure StartDiscovery();
    procedure FinishDiscovery();
  public
    destructor Destroy(); override;
    class function Execute(AOwner: TComponent;
                           var AAddress: string): Boolean;
  end;

implementation

uses
  WinApi.WinSock2,
  WinApi.IpTypes;

{$R *.dfm}

const
  ICMP_TIMEOUT_MS = 40;
  IF_TYPE_ETHERNET_CSMACD = 6;
  IF_TYPE_IEEE80211 = 71;
  IF_OPER_STATUS_UP = 1;
  GAA_FLAG_SKIP_ANYCAST = $0002;
  GAA_FLAG_SKIP_MULTICAST = $0004;
  GAA_FLAG_SKIP_DNS_SERVER = $0008;
  PING_WORKER_COUNT = 32;
  LAN_NI_MAXHOST = 1025;
  LAN_NI_NOFQDN = $01;
  LAN_NI_NAMEREQD = $04;

type
  TIpOptionInformation = packed record
    Ttl: Byte;
    Tos: Byte;
    Flags: Byte;
    OptionsSize: Byte;
    OptionsData: PByte;
  end;

  TIcmpEchoReply = packed record
    Address: ULONG;
    Status: ULONG;
    RoundTripTime: ULONG;
    DataSize: Word;
    Reserved: Word;
    Data: Pointer;
    Options: TIpOptionInformation;
  end;
  PIcmpEchoReply = ^TIcmpEchoReply;

  TMibIpNetRow = record
    Index: DWORD;
    PhysicalAddressLength: DWORD;
    PhysicalAddress: array[0..7] of Byte;
    Address: DWORD;
    EntryType: DWORD;
  end;
  PMibIpNetRow = ^TMibIpNetRow;

  PAnsiCharPointer = ^PAnsiChar;
  PHostEntCompat = ^THostEntCompat;
  THostEntCompat = record
    h_name: PAnsiChar;
    h_aliases: PAnsiCharPointer;
    h_addrtype: Smallint;
    h_length: Smallint;
    h_addr_list: PAnsiCharPointer;
  end;


function IcmpCreateFile(): THandle; stdcall; external 'iphlpapi.dll';
function IcmpCloseHandle(const AIcmpHandle: THandle): BOOL; stdcall;
  external 'iphlpapi.dll';
function IcmpSendEcho(const AIcmpHandle: THandle;
                      const ADestinationAddress: ULONG;
                      const ARequestData: Pointer;
                      const ARequestSize: Word;
                      const ARequestOptions: Pointer;
                      const AReplyBuffer: Pointer;
                      const AReplySize: DWORD;
                      const ATimeout: DWORD): DWORD; stdcall;
  external 'iphlpapi.dll';
function GetIpNetTable(const ATable: Pointer;
                       var ASize: ULONG;
                       const AOrder: BOOL): DWORD; stdcall;
  external 'iphlpapi.dll';
function GetAdaptersAddresses(const AFamily: ULONG;
                              const AFlags: ULONG;
                              const AReserved: Pointer;
                              const AAdapters: PIP_ADAPTER_ADDRESSES;
                              const ASize: PULONG): ULONG; stdcall;
  external 'iphlpapi.dll';
function RawSendTo(const ASocket: TSocket;
                   const ABuffer: Pointer;
                   const ALength,
                         AFlags: Integer;
                   const AAddress: Pointer;
                   const AAddressLength: Integer): Integer; stdcall;
  external 'ws2_32.dll' name 'sendto';
function RawReceiveFrom(const ASocket: TSocket;
                        const ABuffer: Pointer;
                        const ALength,
                              AFlags: Integer;
                        const AAddress: Pointer;
                        const AAddressLength: PInteger): Integer; stdcall;
  external 'ws2_32.dll' name 'recvfrom';
function RawGetNameInfoW(const ASockAddr: Pointer;
                         const ASockAddrLength: Integer;
                         const AHost: PWideChar;
                         const AHostLength: DWORD;
                         const AService: PWideChar;
                         const AServiceLength: DWORD;
                         const AFlags: Integer): Integer; stdcall;
  external 'ws2_32.dll' name 'GetNameInfoW';
function RawGetHostByAddr(const AAddress: PAnsiChar;
                          const AAddressLength,
                                AAddressType: Integer): PHostEntCompat; stdcall;
  external 'ws2_32.dll' name 'gethostbyaddr';


function IPv4ToString(const AAddress: TInAddr): string;
begin
  Result := Format('%d.%d.%d.%d',
                   [Integer(AAddress.S_un_b.s_b1),
                    Integer(AAddress.S_un_b.s_b2),
                    Integer(AAddress.S_un_b.s_b3),
                    Integer(AAddress.S_un_b.s_b4)]);
end;


function IsPrivateIPv4(const AAddress: TInAddr): Boolean;
var
  A: Integer;
  B: Integer;
begin
  A := Integer(AAddress.S_un_b.s_b1);
  B := Integer(AAddress.S_un_b.s_b2);
  Result := (A = 10) or
            ((A = 172) and (B >= 16) and (B <= 31)) or
            ((A = 192) and (B = 168));
end;


function SubnetPrefix(const AAddress: TInAddr): string;
begin
  Result := Format('%d.%d.%d',
                   [Integer(AAddress.S_un_b.s_b1),
                    Integer(AAddress.S_un_b.s_b2),
                    Integer(AAddress.S_un_b.s_b3)]);
end;


function ReadNetworkWord(const ABuffer: array of Byte;
                         const AOffset: Integer): Word;
begin
  Result := (Word(ABuffer[AOffset]) shl 8) or
            Word(ABuffer[AOffset + 1]);
end;


function CleanResolvedName(const AName: string): string;
begin
  Result := Trim(AName);
  while (Length(Result) > 0) and
        (Result[Length(Result)] = '.') do
    Delete(Result, Length(Result), 1);
end;


procedure AddUniqueName(const ANames: TStrings;
                        const AName: string);
var
  Candidate: string;
  I: Integer;
begin
  Candidate := CleanResolvedName(AName);
  if Candidate = '' then
    Exit;
  for I := 0 to ANames.Count - 1 do
    if SameText(ANames[I], Candidate) then
      Exit;
  ANames.Add(Candidate);
end;


function JoinNames(const ANames: TStrings): string;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to ANames.Count - 1 do
    begin
      if Result <> '' then
        Result := Result + '; ';
      Result := Result + ANames[I];
    end;
end;


function ResolveWindowsNames(const AAddress: string;
                             out AName: string;
                             const AAliases: TStrings): Boolean;
var
  SocketAddress: TSockAddrIn;
  HostBuffer: array[0..LAN_NI_MAXHOST - 1] of WideChar;
  NetworkAddress: ULONG;
  HostEntry: PHostEntCompat;
  AliasPointer: PAnsiCharPointer;
  Candidate: string;
begin
  Result := False;
  AName := '';
  AAliases.Clear();

  NetworkAddress := inet_addr(PAnsiChar(AnsiString(AAddress)));
  if NetworkAddress = $FFFFFFFF then
    Exit;

  FillChar(SocketAddress, SizeOf(SocketAddress), 0);
  SocketAddress.sin_family := AF_INET;
  SocketAddress.sin_addr.S_addr := NetworkAddress;

  FillChar(HostBuffer, SizeOf(HostBuffer), 0);
  if RawGetNameInfoW(@SocketAddress,
                     SizeOf(SocketAddress),
                     @HostBuffer[0],
                     Length(HostBuffer),
                     nil,
                     0,
                     LAN_NI_NOFQDN or
                     LAN_NI_NAMEREQD) = 0 then
    begin
      AName := CleanResolvedName(string(PWideChar(@HostBuffer[0])));
      Result := AName <> '';
    end;

  { gethostbyaddr is retained only to collect legacy aliases that
    getnameinfo deliberately does not return. }
  HostEntry := RawGetHostByAddr(PAnsiChar(@NetworkAddress),
                                SizeOf(NetworkAddress),
                                AF_INET);
  if Assigned(HostEntry) then
    begin
      if Assigned(HostEntry^.h_name) then
        begin
          Candidate := CleanResolvedName(string(AnsiString(HostEntry^.h_name)));
          if AName = '' then
            AName := Candidate
          else if not SameText(AName, Candidate) then
            AddUniqueName(AAliases, Candidate);
        end;

      AliasPointer := HostEntry^.h_aliases;
      while Assigned(AliasPointer) do
        begin
          if not Assigned(AliasPointer^) then
            Break;
          Candidate := CleanResolvedName(string(AnsiString(AliasPointer^)));
          if not SameText(AName, Candidate) then
            AddUniqueName(AAliases, Candidate);
          AliasPointer := PAnsiCharPointer(PByte(AliasPointer) +
                                           SizeOf(PAnsiChar));
        end;
    end;

  Result := AName <> '';
end;


function ResolveNetBiosNames(const AAddress: string;
                             out AName: string;
                             const AAliases: TStrings): Boolean;
const
  NETBIOS_PORT = 137;
  NETBIOS_TIMEOUT_MS = 250;
var
  Sock: TSocket;
  Destination: TSockAddrIn;
  Source: TSockAddrIn;
  SourceSize: Integer;
  Timeout: Integer;
  Query: array[0..49] of Byte;
  Reply: array[0..1023] of Byte;
  TransactionId: Word;
  I: Integer;
  RawNameByte: Byte;
  BytesRead: Integer;
  Position: Integer;
  LabelLength: Integer;
  DataLength: Integer;
  DataOffset: Integer;
  NameCount: Integer;
  NameOffset: Integer;
  NameSuffix: Byte;
  NameFlags: Word;
  Candidate: AnsiString;
begin
  Result := False;
  AName := '';
  AAliases.Clear();
  Sock := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if Sock = INVALID_SOCKET then
    Exit;
  try
    Timeout := NETBIOS_TIMEOUT_MS;
    setsockopt(Sock,
               SOL_SOCKET,
               SO_RCVTIMEO,
               PAnsiChar(@Timeout),
               SizeOf(Timeout));

    FillChar(Query, SizeOf(Query), 0);
    TransactionId := Word(GetTickCount() xor DWORD(inet_addr(PAnsiChar(AnsiString(AAddress)))));
    Query[0] := Byte(TransactionId shr 8);
    Query[1] := Byte(TransactionId and $FF);
    Query[5] := 1;
    Query[12] := 32;
    for I := 0 to 15 do
      begin
        if I = 0 then
          RawNameByte := Ord('*')
        else
          RawNameByte := 0;
        Query[13 + (I * 2)] := Ord('A') + (RawNameByte shr 4);
        Query[14 + (I * 2)] := Ord('A') + (RawNameByte and $0F);
      end;
    Query[45] := 0;
    Query[46] := 0;
    Query[47] := $21;
    Query[48] := 0;
    Query[49] := 1;

    FillChar(Destination, SizeOf(Destination), 0);
    Destination.sin_family := AF_INET;
    Destination.sin_port := htons(NETBIOS_PORT);
    Destination.sin_addr.S_addr := inet_addr(PAnsiChar(AnsiString(AAddress)));
    if RawSendTo(Sock,
                 @Query[0],
                 SizeOf(Query),
                 0,
                 @Destination,
                 SizeOf(Destination)) = SOCKET_ERROR then
      Exit;

    SourceSize := SizeOf(Source);
    FillChar(Source, SizeOf(Source), 0);
    BytesRead := RawReceiveFrom(Sock,
                                @Reply[0],
                                SizeOf(Reply),
                                0,
                                @Source,
                                @SourceSize);
    if (BytesRead <= 0) or (BytesRead < 63) then
      Exit;
    if (Reply[0] <> Query[0]) or (Reply[1] <> Query[1]) then
      Exit;

    Position := 50;
    if (Reply[Position] and $C0) = $C0 then
      Inc(Position, 2)
    else
      begin
        while (Position < BytesRead) and (Reply[Position] <> 0) do
          begin
            LabelLength := Reply[Position];
            Inc(Position, LabelLength + 1);
          end;
        Inc(Position);
      end;
    if (Position + 10 > BytesRead) or
       (ReadNetworkWord(Reply, Position) <> $21) then
      Exit;
    DataLength := ReadNetworkWord(Reply, Position + 8);
    DataOffset := Position + 10;
    if (DataOffset + DataLength > BytesRead) or (DataLength < 1) then
      Exit;

    NameCount := Reply[DataOffset];
    for I := 0 to NameCount - 1 do
      begin
        NameOffset := DataOffset + 1 + (I * 18);
        if NameOffset + 18 > BytesRead then
          Break;
        NameSuffix := Reply[NameOffset + 15];
        NameFlags := ReadNetworkWord(Reply, NameOffset + 16);
        if (NameSuffix in [$00, $20]) and ((NameFlags and $8000) = 0) then
          begin
            SetString(Candidate,
                      PAnsiChar(@Reply[NameOffset]),
                      15);
            Candidate := AnsiString(Trim(string(Candidate)));
            if Candidate <> '' then
              begin
                if AName = '' then
                  AName := string(Candidate)
                else if not SameText(AName, string(Candidate)) then
                  AddUniqueName(AAliases, string(Candidate));
                Result := True;
              end;
          end;
      end;
  finally
    closesocket(Sock);
  end;
end;


function ResolveDeviceNames(const AAddress: string;
                            out AName: string;
                            const AAliases: TStrings): Boolean;
var
  WindowsName: string;
  NetBiosName: string;
  WindowsAliases: TStringList;
  NetBiosAliases: TStringList;
  I: Integer;
begin
  AName := '';
  AAliases.Clear();
  WindowsAliases := TStringList.Create();
  NetBiosAliases := TStringList.Create();
  try
    if ResolveWindowsNames(AAddress,
                           WindowsName,
                           WindowsAliases) then
      begin
        AName := WindowsName;
        for I := 0 to WindowsAliases.Count - 1 do
          AddUniqueName(AAliases, WindowsAliases[I]);
      end;

    if ResolveNetBiosNames(AAddress,
                           NetBiosName,
                           NetBiosAliases) then
      begin
        if AName = '' then
          AName := NetBiosName
        else if not SameText(AName, NetBiosName) then
          AddUniqueName(AAliases, NetBiosName);
        for I := 0 to NetBiosAliases.Count - 1 do
          if not SameText(AName, NetBiosAliases[I]) then
            AddUniqueName(AAliases, NetBiosAliases[I]);
      end;

    Result := AName <> '';
  finally
    NetBiosAliases.Free;
    WindowsAliases.Free;
  end;
end;


type
  TLanPingThread = class(TThread)
  private
    FSubnets: TStringList;
    FLocalAddresses: TStringList;
    FWorkerIndex: Integer;
    FWorkerCount: Integer;
    FProgressTarget: PInteger;
    FResults: TStringList;
    FFinishedFlag: Integer;
  protected
    procedure Execute(); override;
  public
    constructor Create(const ASubnets,
                             ALocalAddresses: TStringList;
                       const AWorkerIndex,
                             AWorkerCount: Integer;
                       const AProgressTarget: PInteger);
    destructor Destroy(); override;
    function IsFinished(): Boolean;
    property Results: TStringList read FResults;
  end;


constructor TLanPingThread.Create(const ASubnets,
                                        ALocalAddresses: TStringList;
                                  const AWorkerIndex,
                                        AWorkerCount: Integer;
                                  const AProgressTarget: PInteger);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FSubnets := ASubnets;
  FLocalAddresses := ALocalAddresses;
  FWorkerIndex := AWorkerIndex;
  FWorkerCount := AWorkerCount;
  FProgressTarget := AProgressTarget;
  FResults := TStringList.Create();
  FFinishedFlag := 0;
end;


destructor TLanPingThread.Destroy();
begin
  FResults.Free;
  inherited Destroy();
end;


function TLanPingThread.IsFinished(): Boolean;
begin
  Result := InterlockedCompareExchange(FFinishedFlag, 0, 0) <> 0;
end;


procedure TLanPingThread.Execute();
var
  IcmpHandle: THandle;
  ReplyBuffer: array[0..255] of Byte;
  TargetNumber: Integer;
  TotalTargets: Integer;
  SubnetIndex: Integer;
  HostIndex: Integer;
  IpText: string;
  TargetText: AnsiString;
  TargetAddress: ULONG;
  ReplyCount: DWORD;
begin
  IcmpHandle := INVALID_HANDLE_VALUE;
  try
    IcmpHandle := IcmpCreateFile();
    if IcmpHandle = INVALID_HANDLE_VALUE then
      Exit;

    TotalTargets := FSubnets.Count * 254;
    TargetNumber := FWorkerIndex;
    while TargetNumber < TotalTargets do
      begin
        if Terminated then
          Exit;
        SubnetIndex := TargetNumber div 254;
        HostIndex := (TargetNumber mod 254) + 1;
        IpText := FSubnets[SubnetIndex] + '.' + IntToStr(HostIndex);
        if FLocalAddresses.IndexOf(IpText) < 0 then
          begin
            TargetText := AnsiString(IpText);
            TargetAddress := inet_addr(PAnsiChar(TargetText));
            FillChar(ReplyBuffer, SizeOf(ReplyBuffer), 0);
            ReplyCount := IcmpSendEcho(IcmpHandle,
                                       TargetAddress,
                                       nil,
                                       0,
                                       nil,
                                       @ReplyBuffer[0],
                                       SizeOf(ReplyBuffer),
                                       ICMP_TIMEOUT_MS);
            if (ReplyCount > 0) and
               (PIcmpEchoReply(@ReplyBuffer[0])^.Status = 0) then
              FResults.Add(IpText);
          end;
        InterlockedIncrement(FProgressTarget^);
        Inc(TargetNumber, FWorkerCount);
      end;
  finally
    if IcmpHandle <> INVALID_HANDLE_VALUE then
      IcmpCloseHandle(IcmpHandle);
    InterlockedExchange(FFinishedFlag, 1);
  end;
end;


constructor TLanDiscoveryThread.Create();
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FResults := TStringList.Create();
  FResults.NameValueSeparator := '=';
  FAliases := TStringList.Create();
  FAliases.NameValueSeparator := '=';
  FProgress := 0;
  FTotal := 0;
  FFinishedFlag := 0;
end;


destructor TLanDiscoveryThread.Destroy();
begin
  FAliases.Free;
  FResults.Free;
  inherited Destroy();
end;


procedure TLanDiscoveryThread.AddAddress(const AAddress: string);
begin
  if (AAddress <> '') and (FResults.IndexOfName(AAddress) < 0) then
    FResults.Add(AAddress + '=');
end;


function TLanDiscoveryThread.IsFinished(): Boolean;
begin
  Result := InterlockedCompareExchange(FFinishedFlag, 0, 0) <> 0;
end;


function TLanDiscoveryThread.Progress(): Integer;
begin
  Result := InterlockedCompareExchange(FProgress, 0, 0);
end;


function TLanDiscoveryThread.Total(): Integer;
begin
  Result := InterlockedCompareExchange(FTotal, 0, 0);
end;


procedure TLanDiscoveryThread.Execute();
var
  WsaData: TWSAData;
  AdapterBuffer: PIP_ADAPTER_ADDRESSES;
  AdapterBufferSize: ULONG;
  Adapter: PIP_ADAPTER_ADDRESSES;
  UnicastAddress: PIP_ADAPTER_UNICAST_ADDRESS;
  SocketAddress: PSockAddrIn;
  Address: TInAddr;
  LocalAddresses: TStringList;
  Subnets: TStringList;
  TableBuffer: Pointer;
  TableSize: ULONG;
  TableCount: DWORD;
  Row: PMibIpNetRow;
  I: Integer;
  IpText: string;
  Prefix: string;
  ErrorCode: DWORD;
  PingWorkers: array of TLanPingThread;
  WorkerCount: Integer;
  WorkerIndex: Integer;
  AllWorkersFinished: Boolean;
  ResolvedName: string;
  ResolvedAliases: TStringList;
begin
  LocalAddresses := TStringList.Create();
  Subnets := TStringList.Create();
  TableBuffer := nil;
  AdapterBuffer := nil;
  try
    try
      if WSAStartup($0202, WsaData) <> 0 then
        begin
          FErrorText := 'Windows networking could not be initialized.';
          Exit;
        end;
      try
        AdapterBufferSize := 0;
        ErrorCode := GetAdaptersAddresses(AF_INET,
                                          GAA_FLAG_SKIP_ANYCAST or
                                          GAA_FLAG_SKIP_MULTICAST or
                                          GAA_FLAG_SKIP_DNS_SERVER,
                                          nil,
                                          nil,
                                          @AdapterBufferSize);
        if (ErrorCode <> ERROR_BUFFER_OVERFLOW) or
           (AdapterBufferSize = 0) then
          begin
            FErrorText := 'No local IPv4 network adapter was found.';
            Exit;
          end;

        GetMem(AdapterBuffer, AdapterBufferSize);
        ErrorCode := GetAdaptersAddresses(AF_INET,
                                          GAA_FLAG_SKIP_ANYCAST or
                                          GAA_FLAG_SKIP_MULTICAST or
                                          GAA_FLAG_SKIP_DNS_SERVER,
                                          nil,
                                          AdapterBuffer,
                                          @AdapterBufferSize);
        if ErrorCode <> NO_ERROR then
          begin
            FErrorText := Format('Local network adapters could not be enumerated (error %d).',
                                 [ErrorCode]);
            Exit;
          end;

        Adapter := AdapterBuffer;
        while Assigned(Adapter) do
          begin
            if (Ord(Adapter^.OperStatus) = IF_OPER_STATUS_UP) and
               ((Adapter^.IfType = IF_TYPE_ETHERNET_CSMACD) or
                (Adapter^.IfType = IF_TYPE_IEEE80211)) then
              begin
                UnicastAddress := Adapter^.FirstUnicastAddress;
                while Assigned(UnicastAddress) do
                  begin
                    if Assigned(UnicastAddress^.Address.lpSockaddr) and
                       (UnicastAddress^.Address.lpSockaddr^.sa_family = AF_INET) then
                      begin
                        SocketAddress := PSockAddrIn(UnicastAddress^.Address.lpSockaddr);
                        Address := SocketAddress^.sin_addr;
                        if IsPrivateIPv4(Address) then
                          begin
                            IpText := IPv4ToString(Address);
                            if LocalAddresses.IndexOf(IpText) < 0 then
                              LocalAddresses.Add(IpText);
                            Prefix := SubnetPrefix(Address);
                            if Subnets.IndexOf(Prefix) < 0 then
                              Subnets.Add(Prefix);
                          end;
                      end;
                    UnicastAddress := UnicastAddress^.Next;
                  end;
              end;
            Adapter := Adapter^.Next;
          end;

        if Subnets.Count = 0 then
          begin
            FErrorText := 'No active private IPv4 network was found.';
            Exit;
          end;

        InterlockedExchange(FTotal, Subnets.Count * 254);
        WorkerCount := PING_WORKER_COUNT;
        if WorkerCount > FTotal then
          WorkerCount := FTotal;
        SetLength(PingWorkers, WorkerCount);
        try
          for WorkerIndex := 0 to WorkerCount - 1 do
            begin
              PingWorkers[WorkerIndex] := TLanPingThread.Create(Subnets,
                                                                LocalAddresses,
                                                                WorkerIndex,
                                                                WorkerCount,
                                                                @FProgress);
              PingWorkers[WorkerIndex].Start();
            end;

          repeat
            AllWorkersFinished := True;
            for WorkerIndex := 0 to WorkerCount - 1 do
              begin
                if Terminated then
                  PingWorkers[WorkerIndex].Terminate();
                if not PingWorkers[WorkerIndex].IsFinished() then
                  AllWorkersFinished := False;
              end;
            if not AllWorkersFinished then
              Sleep(20);
          until AllWorkersFinished;

          for WorkerIndex := 0 to WorkerCount - 1 do
            begin
              PingWorkers[WorkerIndex].WaitFor();
              for I := 0 to PingWorkers[WorkerIndex].Results.Count - 1 do
                AddAddress(PingWorkers[WorkerIndex].Results[I]);
              PingWorkers[WorkerIndex].Free;
              PingWorkers[WorkerIndex] := nil;
            end;
        finally
          { Also clean up workers when creation, startup, or discovery raises. }
          for WorkerIndex := 0 to Length(PingWorkers) - 1 do
            if Assigned(PingWorkers[WorkerIndex]) then
              PingWorkers[WorkerIndex].Terminate();
          for WorkerIndex := 0 to Length(PingWorkers) - 1 do
            if Assigned(PingWorkers[WorkerIndex]) then
              begin
                PingWorkers[WorkerIndex].WaitFor();
                PingWorkers[WorkerIndex].Free;
                PingWorkers[WorkerIndex] := nil;
              end;
          SetLength(PingWorkers, 0);
        end;

        if Terminated then
          Exit;

        { Include local-layer neighbors that answered ARP but block ICMP echo. }
        TableSize := 0;
        ErrorCode := GetIpNetTable(nil, TableSize, False);
        if (ErrorCode = ERROR_INSUFFICIENT_BUFFER) and (TableSize > 0) then
          begin
            GetMem(TableBuffer, TableSize);
            if GetIpNetTable(TableBuffer, TableSize, True) = NO_ERROR then
              begin
                TableCount := PDWORD(TableBuffer)^;
                for I := 0 to Integer(TableCount) - 1 do
                  begin
                    Row := PMibIpNetRow(PByte(TableBuffer) +
                                        SizeOf(DWORD) +
                                        (I * SizeOf(TMibIpNetRow)));
                    if (Row^.PhysicalAddressLength >= 6) and
                       (Row^.EntryType in [3, 4]) and
                       ((Row^.PhysicalAddress[0] and $01) = 0) then
                      begin
                        Address.S_addr := Row^.Address;
                        if IsPrivateIPv4(Address) and
                           (Subnets.IndexOf(SubnetPrefix(Address)) >= 0) then
                          begin
                            IpText := IPv4ToString(Address);
                            if LocalAddresses.IndexOf(IpText) < 0 then
                              AddAddress(IpText);
                          end;
                      end;
                  end;
              end;
          end;

        InterlockedExchange(FTotal,
                            (Subnets.Count * 254) + FResults.Count);
        ResolvedAliases := TStringList.Create();
        try
          for I := 0 to FResults.Count - 1 do
            begin
              if Terminated then
                Exit;
              ResolvedAliases.Clear();
              if ResolveDeviceNames(FResults.Names[I],
                                    ResolvedName,
                                    ResolvedAliases) then
                FResults.ValueFromIndex[I] := ResolvedName;
              if ResolvedAliases.Count > 0 then
                FAliases.Values[FResults.Names[I]] := JoinNames(ResolvedAliases);
              InterlockedIncrement(FProgress);
            end;
        finally
          ResolvedAliases.Free;
        end;

      finally
        WSACleanup();
      end;
    except
      on E: Exception do
        FErrorText := E.Message;
    end;
  finally
    if Assigned(TableBuffer) then
      FreeMem(TableBuffer);
    if Assigned(AdapterBuffer) then
      FreeMem(AdapterBuffer);
    Subnets.Free;
    LocalAddresses.Free;
    InterlockedExchange(FFinishedFlag, 1);
  end;
end;


destructor TLanDiscoveryDialog.Destroy();
begin
  tmrDiscovery.Enabled := False;
  if Assigned(FWorker) then
    begin
      FWorker.Terminate();
      FWorker.WaitFor();
      FWorker.Free;
    end;
  inherited Destroy();
end;


class function TLanDiscoveryDialog.Execute(AOwner: TComponent;
                                           var AAddress: string): Boolean;
var
  Dialog: TLanDiscoveryDialog;
begin
  Dialog := TLanDiscoveryDialog.Create(AOwner);
  try
    Dialog.StartDiscovery();
    Result := Dialog.ShowModal() = mrOK;
    if Result then
      AAddress := Dialog.FAddress;
  finally
    Dialog.Free;
  end;
end;


procedure TLanDiscoveryDialog.StartDiscovery();
begin
  if Assigned(FWorker) then
    begin
      FWorker.Terminate();
      FWorker.WaitFor();
      FWorker.Free;
    end;
  lvDevices.Items.Clear();
  btnUseIP.Enabled := False;
  btnRefresh.Enabled := False;
  lblStatus.Caption := 'Searching private IPv4 networks (best effort)...';
  pbDiscovery.Position := 0;
  FWorker := TLanDiscoveryThread.Create();
  tmrDiscovery.Enabled := True;
  FWorker.Start();
end;


procedure TLanDiscoveryDialog.FinishDiscovery();
var
  I: Integer;
  Item: TListItem;
  DeviceName: string;
  AliasNames: string;
begin
  tmrDiscovery.Enabled := False;
  lvDevices.Items.BeginUpdate();
  try
    for I := 0 to FWorker.Results.Count - 1 do
      begin
        Item := lvDevices.Items.Add();
        DeviceName := FWorker.Results.ValueFromIndex[I];
        if DeviceName = '' then
          DeviceName := '(name unavailable)';
        Item.Caption := DeviceName;
        AliasNames := FWorker.Aliases.Values[FWorker.Results.Names[I]];
        Item.SubItems.Add(AliasNames);
        Item.SubItems.Add(FWorker.Results.Names[I]);
      end;
  finally
    lvDevices.Items.EndUpdate();
  end;
  if FWorker.ErrorText <> '' then
    lblStatus.Caption := FWorker.ErrorText
  else
    lblStatus.Caption := Format('%d LAN device(s) found. Names use Windows resolution with NetBIOS fallback.',
                                [lvDevices.Items.Count]);
  pbDiscovery.Position := pbDiscovery.Max;
  btnRefresh.Enabled := True;
end;


procedure TLanDiscoveryDialog.tmrDiscoveryTimer(Sender: TObject);
var
  TotalCount: Integer;
begin
  if not Assigned(FWorker) then
    Exit;
  TotalCount := FWorker.Total();
  if TotalCount > 0 then
    pbDiscovery.Position := (FWorker.Progress() * pbDiscovery.Max) div TotalCount;
  if FWorker.IsFinished() then
    FinishDiscovery();
end;


procedure TLanDiscoveryDialog.btnRefreshClick(Sender: TObject);
begin
  StartDiscovery();
end;


procedure TLanDiscoveryDialog.btnUseIPClick(Sender: TObject);
begin
  if Assigned(lvDevices.Selected) and
     (lvDevices.Selected.SubItems.Count > 1) then
    begin
      FAddress := lvDevices.Selected.SubItems[1];
      ModalResult := mrOK;
    end;
end;


procedure TLanDiscoveryDialog.lvDevicesDblClick(Sender: TObject);
begin
  btnUseIPClick(Sender);
end;


procedure TLanDiscoveryDialog.lvDevicesSelectItem(Sender: TObject;
                                                  Item: TListItem;
                                                  Selected: Boolean);
begin
  btnUseIP.Enabled := Assigned(lvDevices.Selected);
end;

end.
